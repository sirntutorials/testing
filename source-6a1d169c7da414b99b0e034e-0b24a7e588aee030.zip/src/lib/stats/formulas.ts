export type PlayerStatRow = {
  attackKill: number
  attackError: number
  attackAttempt: number
  serveAce: number
  serveError: number
  serveAttempt: number
  receptionPerfect: number
  receptionGood: number
  receptionOk: number
  receptionError: number
  setAssist: number
  setAttempt: number
  setBallHandlingError: number
  blockSolo: number
  blockAssist: number
  blockError: number
  dig: number
  digError: number
}

export const fmt2 = (n: number | null) => (n === null ? '—' : n.toFixed(2))
export const fmtPct = (n: number | null) => (n === null ? '—' : n.toFixed(1) + '%')
export const fmtEff = (n: number | null) => (n === null ? '—' : n.toFixed(3))

export const attackEfficiency = (K: number, E: number, Att: number) =>
  Att > 0 ? (K - E) / Att : null

export const killPct = (K: number, Att: number) =>
  Att > 0 ? (K / Att) * 100 : null

export const serveAcePct = (SA: number, SO: number) =>
  SO > 0 ? (SA / SO) * 100 : null

export const serveErrorPct = (SE: number, SO: number) =>
  SO > 0 ? (SE / SO) * 100 : null

export const passEfficiency = (
  perfect: number,
  good: number,
  ok: number,
  error: number,
) => {
  const total = perfect + good + ok + error
  return total > 0 ? (3 * perfect + 2 * good + 1 * ok) / total : null
}

export const blockTotal = (BS: number, BA: number) => BS + BA * 0.5

export const blocksPerSet = (BS: number, BA: number, sets: number) =>
  sets > 0 ? blockTotal(BS, BA) / sets : null

export const pointsTotal = (K: number, SA: number, BS: number, BA: number) =>
  K + SA + BS + Math.round(BA * 0.5)

export const pointsPerSet = (PTS: number, sets: number) =>
  sets > 0 ? PTS / sets : null

export const perSet = (count: number, sets: number) =>
  sets > 0 ? count / sets : null

export const aggregateTeamStats = (rows: PlayerStatRow[]) => ({
  attackKill: rows.reduce((s, r) => s + r.attackKill, 0),
  attackError: rows.reduce((s, r) => s + r.attackError, 0),
  attackAttempt: rows.reduce((s, r) => s + r.attackAttempt, 0),
  serveAce: rows.reduce((s, r) => s + r.serveAce, 0),
  serveError: rows.reduce((s, r) => s + r.serveError, 0),
  serveAttempt: rows.reduce((s, r) => s + r.serveAttempt, 0),
  receptionPerfect: rows.reduce((s, r) => s + r.receptionPerfect, 0),
  receptionGood: rows.reduce((s, r) => s + r.receptionGood, 0),
  receptionOk: rows.reduce((s, r) => s + r.receptionOk, 0),
  receptionError: rows.reduce((s, r) => s + r.receptionError, 0),
  setAssist: rows.reduce((s, r) => s + r.setAssist, 0),
  setAttempt: rows.reduce((s, r) => s + r.setAttempt, 0),
  setBallHandlingError: rows.reduce((s, r) => s + r.setBallHandlingError, 0),
  blockSolo: rows.reduce((s, r) => s + r.blockSolo, 0),
  blockAssist: rows.reduce((s, r) => s + r.blockAssist, 0),
  blockError: rows.reduce((s, r) => s + r.blockError, 0),
  dig: rows.reduce((s, r) => s + r.dig, 0),
  digError: rows.reduce((s, r) => s + r.digError, 0),
})

export const STAT_FIELDS = [
  'attackKill', 'attackError', 'attackAttempt',
  'serveAce', 'serveError', 'serveAttempt',
  'receptionPerfect', 'receptionGood', 'receptionOk', 'receptionError',
  'setAssist', 'setAttempt', 'setBallHandlingError',
  'blockSolo', 'blockAssist', 'blockError',
  'dig', 'digError',
] as const

export type StatField = (typeof STAT_FIELDS)[number]
