import { createFileRoute } from '@tanstack/react-router'
import { useState, useMemo } from 'react'
import { getAllPlayerStats } from '@/server/stats.functions'
import {
  type PlayerStatRow,
  attackEfficiency,
  killPct,
  passEfficiency,
  blocksPerSet,
  pointsTotal,
  pointsPerSet,
  perSet,
  fmtPct,
  fmtEff,
  fmt2,
  aggregateTeamStats,
} from '@/lib/stats/formulas'
import { Trophy, X } from 'lucide-react'

export const Route = createFileRoute('/leaderboard')({
  loader: async () => {
    try {
      const { stats, players } = await getAllPlayerStats()
      return { stats, players }
    } catch {
      return { stats: [], players: [] }
    }
  },
  component: LeaderboardPage,
})

type RankingKey =
  | 'killPct'
  | 'attackEff'
  | 'passEff'
  | 'totalPts'
  | 'ptsPerSet'
  | 'aces'
  | 'digsPerSet'
  | 'blocksPerSet'

const RANKINGS: { key: RankingKey; label: string; minLabel?: string }[] = [
  { key: 'killPct', label: 'Top Kill%', minLabel: 'min 10 attempts' },
  { key: 'attackEff', label: 'Top Attack Efficiency', minLabel: 'min 10 attempts' },
  { key: 'passEff', label: 'Top Pass Efficiency', minLabel: 'min 10 receptions' },
  { key: 'totalPts', label: 'Top Points' },
  { key: 'ptsPerSet', label: 'Top Points/Set' },
  { key: 'aces', label: 'Top Aces' },
  { key: 'digsPerSet', label: 'Top Digs/Set' },
  { key: 'blocksPerSet', label: 'Top Blocks/Set' },
]

function LeaderboardPage() {
  const { stats, players } = Route.useLoaderData() as any
  const [selectedRanking, setSelectedRanking] = useState<RankingKey>('totalPts')
  const [selectedPlayer, setSelectedPlayer] = useState<number | null>(null)

  const playerMap = useMemo(() => {
    const map: Record<number, { nickname: string; jerseyNumber: number | null; position: string }> = {}
    for (const p of players) {
      map[p.id] = { nickname: p.nickname, jerseyNumber: p.jerseyNumber, position: p.position }
    }
    return map
  }, [players])

  const aggregated = useMemo(() => {
    const byPlayer: Record<number, { rows: PlayerStatRow[]; sets: Set<string> }> = {}
    for (const s of stats) {
      if (!byPlayer[s.playerId]) byPlayer[s.playerId] = { rows: [], sets: new Set() }
      byPlayer[s.playerId].rows.push(s as any)
      if (s.setNumber > 0) byPlayer[s.playerId].sets.add(`${s.matchId}-${s.setNumber}`)
    }

    return Object.entries(byPlayer).map(([id, data]) => {
      const agg = aggregateTeamStats(data.rows)
      const totalSets = Math.max(data.sets.size, 1)
      const pid = Number(id)
      const info = playerMap[pid]
      const pts = pointsTotal(agg.attackKill, agg.serveAce, agg.blockSolo, agg.blockAssist)
      return {
        playerId: pid,
        name: info?.nickname ?? `Player ${id}`,
        jersey: info?.jerseyNumber,
        position: info?.position ?? '',
        totalSets,
        ...agg,
        killPctVal: killPct(agg.attackKill, agg.attackAttempt),
        attackEffVal: attackEfficiency(agg.attackKill, agg.attackError, agg.attackAttempt),
        passEffVal: passEfficiency(agg.receptionPerfect, agg.receptionGood, agg.receptionOk, agg.receptionError),
        totalPts: pts,
        ptsPerSetVal: pointsPerSet(pts, totalSets),
        blocksPerSetVal: blocksPerSet(agg.blockSolo, agg.blockAssist, totalSets),
        digsPerSetVal: perSet(agg.dig, totalSets),
      }
    })
  }, [stats, playerMap])

  const ranked = useMemo(() => {
    let filtered = [...aggregated]

    switch (selectedRanking) {
      case 'killPct':
        filtered = filtered.filter(p => p.attackAttempt >= 10)
        filtered.sort((a, b) => (b.killPctVal ?? -1) - (a.killPctVal ?? -1))
        break
      case 'attackEff':
        filtered = filtered.filter(p => p.attackAttempt >= 10)
        filtered.sort((a, b) => (b.attackEffVal ?? -1) - (a.attackEffVal ?? -1))
        break
      case 'passEff':
        filtered = filtered.filter(p => (p.receptionPerfect + p.receptionGood + p.receptionOk + p.receptionError) >= 10)
        filtered.sort((a, b) => (b.passEffVal ?? -1) - (a.passEffVal ?? -1))
        break
      case 'totalPts':
        filtered.sort((a, b) => b.totalPts - a.totalPts)
        break
      case 'ptsPerSet':
        filtered.sort((a, b) => (b.ptsPerSetVal ?? 0) - (a.ptsPerSetVal ?? 0))
        break
      case 'aces':
        filtered.sort((a, b) => b.serveAce - a.serveAce)
        break
      case 'digsPerSet':
        filtered.sort((a, b) => (b.digsPerSetVal ?? 0) - (a.digsPerSetVal ?? 0))
        break
      case 'blocksPerSet':
        filtered.sort((a, b) => (b.blocksPerSetVal ?? 0) - (a.blocksPerSetVal ?? 0))
        break
    }

    return filtered
  }, [aggregated, selectedRanking])

  const formatValue = (p: typeof aggregated[0]) => {
    switch (selectedRanking) {
      case 'killPct': return fmtPct(p.killPctVal)
      case 'attackEff': return fmtEff(p.attackEffVal)
      case 'passEff': return fmt2(p.passEffVal)
      case 'totalPts': return String(p.totalPts)
      case 'ptsPerSet': return fmt2(p.ptsPerSetVal)
      case 'aces': return String(p.serveAce)
      case 'digsPerSet': return fmt2(p.digsPerSetVal)
      case 'blocksPerSet': return fmt2(p.blocksPerSetVal)
    }
  }

  const selectedPlayerData = selectedPlayer ? aggregated.find(p => p.playerId === selectedPlayer) : null

  return (
    <div className="max-w-6xl mx-auto px-4 py-8">
      <div className="flex items-center gap-3 mb-8">
        <Trophy size={24} className="text-yellow-400" />
        <div>
          <h1 className="text-2xl font-bold">Player Leaderboard</h1>
          <p className="text-sm text-[rgb(var(--muted-fg))]">VIS Statistics Rankings</p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-[280px_1fr] gap-6">
        {/* Left panel: ranking selector */}
        <div className="space-y-2">
          <h2 className="text-xs font-semibold text-[rgb(var(--muted-fg))] uppercase tracking-wider mb-3">Rankings</h2>
          {RANKINGS.map(r => (
            <button
              key={r.key}
              onClick={() => setSelectedRanking(r.key)}
              className={`w-full text-left px-4 py-3 rounded-xl text-sm font-medium transition-colors ${
                selectedRanking === r.key
                  ? 'bg-blue-600 text-white'
                  : 'bg-[rgb(var(--surface))] border border-[rgb(var(--border))] text-[rgb(var(--fg))] hover:bg-[rgb(var(--surface-hover))]'
              }`}
            >
              <div>{r.label}</div>
              {r.minLabel && (
                <div className={`text-[10px] mt-0.5 ${selectedRanking === r.key ? 'text-blue-200' : 'text-[rgb(var(--muted-fg))]'}`}>
                  {r.minLabel}
                </div>
              )}
            </button>
          ))}
        </div>

        {/* Right panel: ranked table */}
        <div className="bg-[rgb(var(--surface))] border border-[rgb(var(--border))] rounded-2xl overflow-hidden">
          <div className="px-5 py-3 border-b border-[rgb(var(--border))] flex items-center gap-2">
            <Trophy size={15} className="text-yellow-400" />
            <span className="font-semibold text-sm">{RANKINGS.find(r => r.key === selectedRanking)?.label}</span>
          </div>

          {ranked.length === 0 ? (
            <div className="text-center py-16 text-[rgb(var(--muted-fg))] text-sm">
              No data yet. Record some match stats first.
            </div>
          ) : (
            <div>
              {ranked.map((p, i) => (
                <button
                  key={p.playerId}
                  onClick={() => setSelectedPlayer(p.playerId)}
                  className={`w-full flex items-center gap-4 px-5 py-3.5 border-b border-[rgb(var(--border-soft))] hover:bg-[rgb(var(--surface-hover))] transition-colors text-left ${
                    i % 2 !== 0 ? 'bg-[rgb(var(--surface-hover))]' : ''
                  }`}
                >
                  <div className={`w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold flex-shrink-0 ${
                    i === 0 ? 'bg-yellow-400/20 text-yellow-400 border border-yellow-400/30'
                    : i === 1 ? 'bg-gray-400/20 text-gray-300 border border-gray-400/30'
                    : i === 2 ? 'bg-amber-700/20 text-amber-600 border border-amber-700/30'
                    : 'bg-[rgb(var(--surface-hover))] text-[rgb(var(--muted-fg))]'
                  }`}>
                    {i + 1}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2">
                      <span className="font-medium text-sm">{p.name}</span>
                      <span className="text-xs text-[rgb(var(--muted-fg))] font-mono">#{p.jersey ?? '?'}</span>
                      {p.position && (
                        <span className="text-[10px] px-1.5 py-0.5 bg-[rgb(var(--surface-hover))] rounded text-[rgb(var(--muted-fg))]">
                          {p.position}
                        </span>
                      )}
                    </div>
                  </div>
                  <div className="text-base font-bold tabular-nums text-blue-400">
                    {formatValue(p)}
                  </div>
                </button>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Player profile modal */}
      {selectedPlayerData && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" onClick={() => setSelectedPlayer(null)} />
          <div className="relative bg-[rgb(var(--surface))] border border-[rgb(var(--border))] rounded-2xl shadow-2xl p-6 max-w-lg w-full max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between mb-5">
              <div>
                <h3 className="text-lg font-bold">
                  #{selectedPlayerData.jersey ?? '?'} {selectedPlayerData.name}
                </h3>
                <p className="text-xs text-[rgb(var(--muted-fg))]">{selectedPlayerData.position || 'No position'}</p>
              </div>
              <button onClick={() => setSelectedPlayer(null)} className="text-[rgb(var(--muted-fg))] hover:text-[rgb(var(--fg))]">
                <X size={20} />
              </button>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <StatCard label="Attack Kill" value={String(selectedPlayerData.attackKill)} />
              <StatCard label="Attack Eff" value={fmtEff(selectedPlayerData.attackEffVal)} />
              <StatCard label="Kill%" value={fmtPct(selectedPlayerData.killPctVal)} />
              <StatCard label="Serve Aces" value={String(selectedPlayerData.serveAce)} />
              <StatCard label="Pass Eff (FIVB)" value={fmt2(selectedPlayerData.passEffVal)} />
              <StatCard label="Block Solo" value={String(selectedPlayerData.blockSolo)} />
              <StatCard label="Block Assist" value={String(selectedPlayerData.blockAssist)} />
              <StatCard label="Blocks/Set" value={fmt2(selectedPlayerData.blocksPerSetVal)} />
              <StatCard label="Digs" value={String(selectedPlayerData.dig)} />
              <StatCard label="Digs/Set" value={fmt2(selectedPlayerData.digsPerSetVal)} />
              <StatCard label="Set Assists" value={String(selectedPlayerData.setAssist)} />
              <StatCard label="Total Points" value={String(selectedPlayerData.totalPts)} highlight />
              <StatCard label="Points/Set" value={fmt2(selectedPlayerData.ptsPerSetVal)} highlight />
              <StatCard label="Sets Played" value={String(selectedPlayerData.totalSets)} />
            </div>
          </div>
        </div>
      )}
    </div>
  )
}

function StatCard({ label, value, highlight }: { label: string; value: string; highlight?: boolean }) {
  return (
    <div className={`px-3 py-2.5 rounded-xl border ${highlight ? 'border-blue-500/30 bg-blue-500/10' : 'border-[rgb(var(--border-soft))] bg-[rgb(var(--bg))]'}`}>
      <div className="text-[10px] text-[rgb(var(--muted-fg))] uppercase tracking-wider">{label}</div>
      <div className={`text-lg font-bold tabular-nums mt-0.5 ${highlight ? 'text-blue-400' : ''}`}>{value}</div>
    </div>
  )
}
