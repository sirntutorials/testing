import { admin } from '@netlify/identity'

const ADMIN_EMAIL = 'admin@rebels.com'
const ADMIN_PASSWORD = 'Therebels2026'

export const handler = async (_event: any, _context: any) => {
  try {
    const users = await admin.listUsers()
    const existing = users.find((u) => u.email?.toLowerCase() === ADMIN_EMAIL)
    if (!existing) {
      await admin.createUser({
        email: ADMIN_EMAIL,
        password: ADMIN_PASSWORD,
        data: {
          app_metadata: { roles: ['admin'] },
        },
      })
      return { statusCode: 200, body: `Created admin user ${ADMIN_EMAIL}` }
    }
    await admin.updateUser(existing.id, { password: ADMIN_PASSWORD })
    const roles = (existing.appMetadata?.roles ?? []) as string[]
    if (!roles.includes('admin')) {
      await admin.updateUser(existing.id, {
        app_metadata: { ...(existing.appMetadata ?? {}), roles: [...roles, 'admin'] },
      })
    }
    return { statusCode: 200, body: `Password reset for ${existing.email}` }
  } catch (err) {
    return { statusCode: 500, body: String(err) }
  }
}
