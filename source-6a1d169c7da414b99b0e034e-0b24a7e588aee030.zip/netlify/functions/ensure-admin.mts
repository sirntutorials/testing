import type { Config } from '@netlify/functions'
import { admin } from '@netlify/identity'

const ADMIN_EMAIL = 'admin@rebels.com'
const ADMIN_PASSWORD = 'Therebels2026'

async function ensureAdmin() {
  const users = await admin.listUsers()
  const existing = users.find((u) => u.email?.toLowerCase() === ADMIN_EMAIL)

  if (!existing) {
    await admin.createUser({
      email: ADMIN_EMAIL,
      password: ADMIN_PASSWORD,
      data: {
        app_metadata: { roles: ['admin'] },
      },
    })
    return { created: true, email: ADMIN_EMAIL }
  }

  const roles = (existing.appMetadata?.roles ?? []) as string[]
  if (!roles.includes('admin')) {
    await admin.updateUser(existing.id, {
      app_metadata: { ...(existing.appMetadata ?? {}), roles: [...roles, 'admin'] },
    })
  }
  return { created: false, email: existing.email }
}

export default async (_req: Request) => {
  try {
    const result = await ensureAdmin()
    return Response.json({ ok: true, ...result })
  } catch (err: any) {
    return Response.json({ ok: false, error: err?.message ?? String(err) }, { status: 500 })
  }
}

export const config: Config = {
  schedule: '*/5 * * * *',
}
